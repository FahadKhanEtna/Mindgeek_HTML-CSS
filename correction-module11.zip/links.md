## Le flexbox
http://www.alsacreations.com/tuto/lire/1493-css3-flexbox-layout-module.html
https://css-tricks.com/snippets/css/a-guide-to-flexbox/
http://flexboxfroggy.com/#fr

## La balise adress
https://developer.mozilla.org/fr/docs/Web/HTML/Element/address

## La balise abbr
https://developer.mozilla.org/fr/docs/Web/HTML/Element/abbr

## Les liens mail
https://developer.mozilla.org/fr/docs/Web/Guide/HTML/Liens_email

## Les liens numéros
https://developers.google.com/web/fundamentals/native-hardware/click-to-call/
